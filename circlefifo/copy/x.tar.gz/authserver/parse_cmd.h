#ifndef __PARSE_CMD_H__
#define __PARSE_CMD_H__

/** 解析命令行参数
 *  argc argv就是传给main函数的那两个参数
 * */
void parse_cmd_line(int argc, char *argv[]);

#endif /*__PARSECMD_H__*/
