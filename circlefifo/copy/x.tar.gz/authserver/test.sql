use wg;
insert into terminals values(1, '12345678', 'hello', 'world');

