#include <linux/interrupt.h>
#include <linux/miscdevice.h>
#include <linux/delay.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/pci.h>
#include <linux/ioctl.h>
#include <linux/sched.h>
#include <linux/irq.h>
#include <asm/uaccess.h>
#include <mach/irqs.h>
#include <mach/regs-irq.h>
#include <mach/gpio.h>
#include <mach/regs-gpio.h>
#include <plat/gpio-cfg.h>


typedef unsigned int  uint32;
typedef unsigned char uint8;

//#define RCV_INT_PORT S5PV210_GPJ3(5)
#define RCV_INT_PORT S5PV210_GPH2(0) //SDWFI 16
//#define RCV_INT_PORT S5PV210_GPH0(0) //

#define SPI0_BASE_ADDR 0xE1300000
#define GPB_BASE_ADDR  0xE0200040
#define s5pv210_CLK 0xE010046C

volatile uint32 __iomem *CLK_GATE_IP3;
#define NAME_LEN 32
#define DEV_NAME "spi_master"

#define info(format, ...) {printk("%s(%d):", __FILE__, __LINE__);printk(format, ##__VA_ARGS__);}
#define NDEBUG
#ifndef NDEBUG
#define debugmsg(format, ...){info(format, ##__VA_ARGS__);}
#else
#define debugmsg(format, ...)
#endif
#define RX_BUF_SIZE (1024*1024*3)
#define TX_BUF_SIZE (1024*1024*3)
#define REG_RX_FIFO_SIZE 256
#define REG_TX_FIFO_SIZE 256
#define DEFAULT_RX_RDY_LVL 0
#define DEFAULT_TX_RDY_LVL 50
#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define MIN(x, y) ((x) < (y) ? (x) : (y))
static char rxbuf[RX_BUF_SIZE];
static char txbuf[TX_BUF_SIZE];
struct circle_buffer
{
	int head;
	int tail;
	char *buf;
	int size;
};

struct gpb_reg
{
	uint32 gpbcon;
	uint32 gpbdat;
	uint32 gpbup;
};

struct spi_reg
{
	volatile uint32 ch;
	uint32 clk;
	uint32 mode;
	uint32 cs;
	uint32 intr;
	uint32 status;
	volatile uint32 txdata;
	uint32 rxdata;
	uint32 pkt_cnt;
	uint32 pdclr;
	uint32 swap;
	uint32 fb_clk_sel;
};

struct spi_device
{
	char name[NAME_LEN];
	volatile struct spi_reg *spi0;
	volatile struct gpb_reg *gpb0;
	struct miscdevice *misc;
	struct circle_buffer rx_buf;
	struct circle_buffer tx_buf;
	volatile int tx_isfull;
	volatile int rx_isnempty;
	int rx_rdy_lvl;
	int tx_rdy_lvl;
	int spi_irq;
	int rcv_irq;
	volatile int stop_read;
	
};

#define CHKBIT(d,n) 		(((d)&(1<<n))!=0)
#define SETBIT(d,n) 		((d)|=(1<<n))
#define CLRBIT(d,n) 		((d)&=~(1<<n))
#define GETDATA(d,s,len) 	((d>>s) & ((1<<len)-1))
#define SETDATA(reg,v,s,len) {reg &= (~((1<<(s+len))-1) | ((1<<s)-1));\
							  reg |= (v&((1<<len)-1))<<s;}

/* CH_CFG operattion */
// High Speed
#define spi_high_speed_on(dev)  SETBIT((dev)->ch, 6)
#define spi_high_speed_off(dev) CLRBIT((dev)->ch, 6)

/* pending clear reg operations*/
#define spi_pdclr_all(dev) (dev)->pdclr = 0x1f

//SW_RST reset reg
#define spi_reset_reg(dev) 	do{SETBIT((dev)->ch, 5);spi_pdclr_all(dev); CLRBIT((dev)->ch, 5);}while(0)

//slave or master
#define spi_set_slave(dev)   SETBIT((dev)->ch, 4)
#define spi_set_master(dev)  CLRBIT((dev)->ch, 4)

//set CPOL CPHA mode0 ~ mode3
#define CLKCP0 0
#define CLKCP1 1
#define CLKCP2 2
#define CLKCP3 3
#define spi_set_clkcp(dev, mode) SETDATA((dev)->ch, (mode), 2, 2)

//turn on or off receive or transfer channel
#define spi_rx_on(dev)  	SETBIT((dev)->ch, 1)
#define spi_rx_off(dev) 	CLRBIT((dev)->ch, 1)
#define spi_tx_on(dev)  	SETBIT((dev)->ch, 0)
#define spi_tx_off(dev) 	CLRBIT((dev)->ch, 0)

/* CLK_CFG operations */
#define spi_clk_set(dev)\
			do{CLRBIT((dev)->clk, 9); SETBIT((dev)->clk, 8);}while(0)
#define spi_clk_divide(dev, n) SETDATA((dev)->clk, (n), 0, 8)

/* MODE_CFG operations */
#define spi_mode_clr(dev) (dev)->mode = 0
#define spi_ch_width(dev, v) SETDATA((dev)->mode, (v), 29, 2)
#define spi_trailing_cnt(dev, v) SETDATA((dev)->mode, (v), 19, 10)
#define spi_bus_width(dev, v) SETDATA((dev)->mode, (v), 17, 2)
#define spi_rx_rdy_lvl(dev, v) SETDATA((dev)->mode, (v), 11, 6)
#define spi_tx_rdy_lvl(dev, v) SETDATA((dev)->mode, (v), 5, 6)
//DMA option
#define spi_rx_dma_sw_on(dev), SETBIT((dev)->mode,2)
#define spi_tx_dma_sw_off(dev), CLRBIT((dev)->mode,2)
#define spi_tx_dma_sw_on(dev), SETBIT((dev)->mode,1)
#define spi_rx_dma_sw_off(dev), CLRBIT((dev)->mode,1)
#define spi_dma_type_single(dev), CLRBIT((dev)->mode,0)
#define spi_dma_type_4bust(dev), SETBIT((dev)->mode,0)

/* CS_REG operations */
#define spi_cs_master(dev) do{SETBIT((dev)->cs, 1); SETBIT((dev)->cs, 0);\
						SETDATA(dev->cs, 0, 2, 8);}while(0)

/* SPI interrupt register operations */
#define spi_int_all_off(dev) (dev)->intr = 0

#define spi_int_trailing_on(dev) SETBIT((dev)->intr, 6)
#define spi_int_trailing_off(dev) CLRBIT((dev)->intr, 6)

#define spi_int_rxoverrun_on(dev) SETBIT((dev)->intr, 5) 
#define spi_int_rxoverrun_off(dev) CLRBIT((dev)->intr, 5) 

#define spi_int_rxunderrun_on(dev) SETBIT((dev)->intr, 4) 
#define spi_int_rxunderrun_off(dev) CLRBIT((dev)->intr, 4) 

#define spi_int_txoverrun_on(dev) SETBIT((dev)->intr, 3) 
#define spi_int_txoverrun_off(dev) CLRBIT((dev)->intr, 3) 

#define spi_int_txunderrun_on(dev) SETBIT((dev)->intr, 2) 
#define spi_int_txunderrun_off(dev) CLRBIT((dev)->intr, 2)

#define spi_int_rxfifordy_on(dev) SETBIT((dev)->intr, 1)
#define spi_int_rxfifordy_off(dev) CLRBIT((dev)->intr, 1)
#define is_int_rx_on(dev) CHKBIT((dev)->intr, 1)

#define spi_int_txfifordy_on(dev) SETBIT((dev)->intr, 0) 
#define spi_int_txfifordy_off(dev) CLRBIT((dev)->intr, 0)
#define is_int_tx_on(dev) CHKBIT((dev)->intr, 0)

/*SPI status operations */
#define is_tx_done(dev) CHKBIT((dev)->status, 25)
#define is_trailing_byte(dev) CHKBIT((dev)->status, 24)
#define get_rx_fifo_lvl(dev) GETDATA((dev)->status, 15, 9)
#define get_tx_fifo_lvl(dev) GETDATA((dev)->status, 6, 9)
#define is_rx_overrun(dev) CHKBIT((dev)->status, 5)
#define is_rx_underrun(dev) CHKBIT((dev)->status, 4)
#define is_tx_overrun(dev) CHKBIT((dev)->status, 3)
#define is_tx_underrun(dev) CHKBIT((dev)->status, 2)
#define is_rx_fifordy(dev) CHKBIT((dev)->status, 1)
#define is_tx_fifordy(dev) CHKBIT((dev)->status, 0)

/* SPI clear error */
#define spi_clr_tx_underrun(dev) do{SETBIT((dev)->ch, 5); SETBIT((dev)->pdclr, 4); CLRBIT((dev)->ch, 5); }while(0)
#define spi_clr_tx_overrun(dev) do{SETBIT((dev)->ch, 5); SETBIT((dev)->pdclr, 3); CLRBIT((dev)->ch, 5); }while(0)
#define spi_clr_rx_underrun(dev) do{SETBIT((dev)->ch, 5); SETBIT((dev)->pdclr, 2); CLRBIT((dev)->ch, 5); }while(0)
#define spi_clr_rx_overrun(dev) do{SETBIT((dev)->ch, 5); SETBIT((dev)->pdclr, 1); CLRBIT((dev)->ch, 5); }while(0)
#define spi_clr_trailing(dev) do{SETBIT((dev)->ch, 5); SETBIT((dev)->pdclr, 0); CLRBIT((dev)->ch, 5); }while(0)

static void show_status(volatile struct spi_reg *spi)
{
	debugmsg("TX_Done:%d TRAILING_BYTE_IS_ZERO:%d  RX_LVL:%d  TX_LvL:%d RX_OVERRUN:%d RX_UNDERRUN:%d  TX_OVERRUN:%d TX_UNDERRUN:%d 	RX_RDY:%d TX_RDY:%d\n", 
			is_tx_done(spi), is_trailing_byte(spi),
			get_rx_fifo_lvl(spi), get_tx_fifo_lvl(spi),
			is_rx_overrun(spi), is_rx_underrun(spi),
			is_tx_overrun(spi), is_tx_underrun(spi),
			is_rx_fifordy(spi), is_tx_fifordy(spi)
			);
}
static void show_config(volatile struct spi_reg *spi)
{
	debugmsg("CH_CFG:%x CLK_CFG:%x MOD_CFG:%x CS_REG:%x INT:%x PACKET_CNT:%x SWAP:%x FD_CLK_SEL:%x\n",
		spi->ch, spi->clk, spi->mode, spi->cs, spi->intr, spi->pkt_cnt,
		spi->swap, spi->fb_clk_sel);
}
#define HAVE_ERROR(s) (((s)&0x3c)!=0)


/* FD clk select */
#define FD_0   0
#define FD_90  1
#define FD_180 2
#define FD_270 1
#define spi_fdclk_sel(dev, v){SETDATA(dev->fb_clk_sel, v, 0, 2);}
static int spi_open(struct inode *inode, struct file *filp);
static ssize_t spi_read(struct file *filp, char __user *buf, 
						size_t count, loff_t *offset);
static ssize_t spi_write(struct file *filp, const char __user *buf,
						 size_t count, loff_t *offset);
static int spi_release(struct inode *inode, struct file *filp);
static DECLARE_WAIT_QUEUE_HEAD(spi_waitq);
static const struct file_operations spi_fops = 
{
	.owner 		= THIS_MODULE,
	.open  		= spi_open,
	.release	= spi_release,
	.read 		= spi_read,
	.write 		= spi_write,
};

static struct miscdevice misc = 
{
	.minor = MISC_DYNAMIC_MINOR,
	.name  = DEV_NAME,
	.fops  = &spi_fops,
};

static struct spi_device spi_dev = 
{
	.name = "spi_master",
	.spi0 = NULL,
	.misc = &misc,
	.rx_buf = {.buf = rxbuf, .size = RX_BUF_SIZE, .head = 0},
	.tx_buf = {.buf = txbuf, .size = TX_BUF_SIZE, .tail = 0},
	.rx_isnempty = 0,
	.tx_isfull = 0,
	.rx_rdy_lvl = DEFAULT_RX_RDY_LVL,
	.tx_rdy_lvl = DEFAULT_TX_RDY_LVL,
	.stop_read = 1,
};

static void cirbuf_init(struct circle_buffer *cb, uint8 *buf, int size)
{
	cb->head = cb->tail = 0;
	cb->buf = buf;
	cb->size = size;
}

static inline void cirbuf_clear(struct circle_buffer *cb)
{
	cb->head = cb->tail = 0;
}
static inline int cirbuf_empty(struct circle_buffer *cb)
{
	return (cb->head == cb->tail);
}

static inline int cirbuf_full(struct circle_buffer *cb)
{
	return (cb->tail == (cb->head + 1) % cb->size);
}

static inline size_t cirbuf_get_free(struct circle_buffer *cb)
{
	return cb->size - ((cb->head - cb->tail) + cb->size) % cb->size -1;
}
static inline int put_byte_to_buf(struct circle_buffer *cb, uint8 b)
{
	if(!cirbuf_full(cb))
	{
		cb->buf[cb->head] = b;
		cb->head = (cb->head + 1) % cb->size;
		return 0;
	}
	else
	{
		info("error:buf is full!!\n");
		return -1;
	}
}
static inline uint8  get_byte_from_buf(struct circle_buffer *cb)
{
	uint8 byte = 0;
	if(!cirbuf_empty(cb))
	{
		byte = cb->buf[cb->tail];
		cb->tail = (cb->tail+1) % cb->size;
		return byte;
	}
	else
	{
		info("error:buff is empty\n");
		return 0xff;
	}
}

/*copy cirbuf's data to user space, use copy to user, so can't call this in an interrupt routing*/

static ssize_t _copy_cirbuf_to_user(struct circle_buffer *cb, uint8 __user *user, size_t len)
{
	int ret;
	int bx_len = cb->head - cb->tail;
	int real_copy_len = MIN(bx_len, len);
	if(cirbuf_empty(cb))
		return 0;
	ret = copy_to_user(user, cb->buf + cb->tail, real_copy_len);
	real_copy_len = real_copy_len - ret;
	cb->tail = (cb->tail + real_copy_len) % cb->size;		
	return real_copy_len;

}
static ssize_t copy_cirbuf_to_user(struct circle_buffer *cb, uint8 __user *user, size_t len)
{
	int real_copy_len = 0;
	debugmsg("len = %d\n", len);
	if(cirbuf_empty(cb))
		real_copy_len = 0;
	else if(cb->head > cb->tail)
		real_copy_len =  _copy_cirbuf_to_user(cb, user, len);
	else
	{
		int tmp_head = cb->head;
		cb->head = cb->size;
		real_copy_len += _copy_cirbuf_to_user(cb, user, len);
		cb->head = tmp_head;

		if(real_copy_len >=0 && len - real_copy_len > 0)
			real_copy_len +=  _copy_cirbuf_to_user(cb, user + real_copy_len, len - real_copy_len);
		
	}

	debugmsg("real_copy: %d bytes, buff_free:%d bytes, buff_used:%d bytes, buff_size:%d byte\n", 
			real_copy_len, cirbuf_get_free(cb), cb->size - cirbuf_get_free(cb), cb->size);
	return real_copy_len;
}

/*copy user_space's data to cirbuf , use copy_from_user, so can't call this in an interrupt routing*/
static ssize_t _copy_cirbuf_from_user(struct circle_buffer *cb, const uint8 __user *user, size_t len)
{
	int ret;
	int bx_len = cb->tail - cb->head - 1;
	int real_copy_len = MIN(bx_len, len);
	if(cirbuf_full(cb))
		return 0;
	ret = copy_from_user(cb->buf + cb->head, user, real_copy_len);
	real_copy_len = real_copy_len - ret;
	cb->head = (cb->head + real_copy_len) % cb->size;		
	return real_copy_len;

}
static ssize_t copy_cirbuf_from_user(struct circle_buffer *cb, const uint8 __user *user, size_t len)
{
	int real_copy_len = 0;
	debugmsg("len = %d\n", len);
	if(cirbuf_full(cb))
		real_copy_len =  0;
	else if(cb->head >= cb->tail)
	{
		int tmp_tail = cb->tail;
		debugmsg("head:%d tail:%d\n", cb->head, cb->tail);
		if(cb->tail == 0)
			cb->tail = cb->size;
		else
			cb->tail = cb->size + 1;
		real_copy_len += _copy_cirbuf_from_user(cb, user, len);
		cb->tail = tmp_tail;
		debugmsg("first copy:%d byte!\n", real_copy_len);
		if(real_copy_len >=0 && len - real_copy_len > 0)
			real_copy_len += _copy_cirbuf_from_user(cb, user + real_copy_len, len - real_copy_len);
	}
	else
		real_copy_len =  _copy_cirbuf_from_user(cb, user, len);	
	
	debugmsg("real_copy: %d bytes, buff_free:%d bytes, buff_used:%d bytes, buff_size:%d byte\n", 
			real_copy_len, cirbuf_get_free(cb), cb->size - cirbuf_get_free(cb), cb->size);
	return real_copy_len;
}
void send_zeros(struct spi_device *dev, int num)
{
	int i;
	spi_int_txfifordy_off(dev->spi0);
	for(i = 0; i < num; i++)
		put_byte_to_buf(&dev->tx_buf, 0);

	spi_tx_rdy_lvl(dev->spi0, dev->tx_rdy_lvl);
	spi_tx_on(dev->spi0);	
	spi_int_txfifordy_on(dev->spi0);
}
static irqreturn_t rcv_interrupt(int irq, void *dev_id)
{
	static int raise = 0;
	struct spi_device *dev = &spi_dev;
	volatile struct spi_reg *spi = dev->spi0;
	raise = gpio_get_value(RCV_INT_PORT);
	if(raise)
	{
		spi_rx_on(spi);
		spi_rx_rdy_lvl(spi, dev->rx_rdy_lvl);
		spi_int_rxfifordy_on(spi);
		send_zeros(dev, 1024);
		dev->stop_read = 0;
	}
	else
	{
		uint8 b;
		dev->stop_read = 1;
		/*spi_rx_off(spi);
		cirbuf_clear(&dev->tx_buf);
		info("rx lvl:%d\n", get_rx_fifo_lvl(spi));
		while(get_rx_fifo_lvl(spi) > 0)
			b = spi->rxdata;
		info("rx lvl:%d\n\n", get_rx_fifo_lvl(spi));
		*/
	}
	debugmsg("rcv_interrupt irq=%d raise=%d...\n", irq, raise);
	return IRQ_HANDLED;
}

static void clear_error(volatile struct spi_reg *spi)
{
	//错误处理
	if(is_tx_underrun(spi))
	{
		info("Tx underrun!\n");
		spi_clr_tx_underrun(spi);
	}
	if(is_tx_overrun(spi))
	{
		info("Tx overrun!\n");
		spi_clr_tx_overrun(spi);
	}
	if(is_rx_underrun(spi))
	{
		info("Rx underrun!\n");
		spi_clr_rx_underrun(spi);
	}
	if(is_tx_overrun(spi))
	{
		info("Rx overrrun!\n");
		spi_clr_rx_underrun(spi);
	}
}

static irqreturn_t spi_interrupt(int irq, void *dev_id)
{
	struct spi_device *dev = &spi_dev;
	volatile struct spi_reg *spi = dev->spi0;
	debugmsg("interrupt!\n");
	show_status(spi);
	clear_error(spi);
	//read
	//
	if(is_int_rx_on(spi))
	{
		uint8 byte;
		if(get_rx_fifo_lvl(spi) > dev->rx_rdy_lvl)
		{
			int cnt = 0;
			int k = 1000;
			while(k--)
			while(get_rx_fifo_lvl(spi) > 0)
			{
				byte = spi->rxdata;
				put_byte_to_buf(&dev->rx_buf, byte);
			//	printk("%2x ", byte);
				cnt++;
			}
			debugmsg("real_read %d bytes\n", cnt);
			show_status(spi);
			if(dev->rx_isnempty == 0)
			{
				debugmsg("wake up reader!\n");
				dev->rx_isnempty = 1;
				wake_up_interruptible(&spi_waitq);
			}
		}
	}
	//write
	if(is_int_rx_on(spi))
	{
		debugmsg("rx interrupt\n");
	}
	if(is_int_tx_on(spi))
	{
		debugmsg("tx interrupt\n");
		if(cirbuf_empty(&dev->tx_buf)) //发送缓冲区空
		{
			if(get_tx_fifo_lvl(spi)==0)
			{
				debugmsg("tx done!\n");
				spi_int_txfifordy_off(spi);
				spi_tx_off(spi);
				spi_rx_off(spi);
				spi_int_rxfifordy_off(spi);
				spi_reset_reg(spi);
			}
			else
			{
				debugmsg("set tx lvl to 1\n");
				spi_tx_rdy_lvl(spi, 1);
			}
		}
		else				 //发送缓冲区非空
		{
			int cnt = 0;
			int raise = 0;
			debugmsg("write reg!\n");
			/*raise = gpio_get_value(RCV_INT_PORT);
			if(raise && !dev->stop_read)
			{
				spi_rx_rdy_lvl(spi, dev->rx_rdy_lvl);
				spi_rx_on(spi);
				spi_int_rxfifordy_on(spi);
			}*/
			if(get_tx_fifo_lvl(spi) < dev->tx_rdy_lvl)
			{
				int snd = REG_RX_FIFO_SIZE - get_tx_fifo_lvl(spi);
				//snd = 256;	
				while(!cirbuf_empty(&dev->tx_buf) && /*snd--)*/get_tx_fifo_lvl(spi) < REG_RX_FIFO_SIZE)
				{
					debugmsg("have data send!\n");
					if(get_tx_fifo_lvl(spi) < REG_TX_FIFO_SIZE)
					{
						spi->txdata = get_byte_from_buf(&dev->tx_buf);
						cnt++;
					}

					while(get_rx_fifo_lvl(spi) > 0)
					{
						uint8 b = spi->rxdata;
						debugmsg("have data read!\n");
						put_byte_to_buf(&dev->rx_buf, b);
					}
					if(!dev->stop_read && !gpio_get_value(RCV_INT_PORT))
					{
						dev->stop_read = 1;
						cirbuf_clear(&dev->tx_buf);
						break;
					}

				}
			}
			if(!dev->stop_read && gpio_get_value(RCV_INT_PORT) && cirbuf_empty(&dev->tx_buf))
			{
				send_zeros(dev, 1024);
			}
			debugmsg("after wirte:buf:%d bytes real_write:%d bytes\n", dev->tx_buf.size - cirbuf_get_free(&dev->tx_buf), cnt);
			if(cirbuf_get_free(&dev->tx_buf) > 0)
			{
				dev->tx_isfull = 0;
				wake_up_interruptible(&spi_waitq);
			}
		}
	}
	//show_status(spi);
	return IRQ_HANDLED;
}
static void spi_reg_init(volatile struct spi_reg *spi);
static int spi_open(struct inode *inode, struct file *filp)
{
	debugmsg("begin opened. spi_dev:%p\n", &spi_dev);
	filp->private_data = &spi_dev;
	spi_reset_reg(spi_dev.spi0);
	return 0;
}
static ssize_t spi_read(struct file *filp, char __user *buf, 
						size_t count, loff_t *offset)
{
	int ret;
	int real_read = 0;
	int have_signal = 0;
	struct spi_device *dev = (struct spi_device *) filp->private_data;
	volatile struct spi_reg *spi = dev->spi0;
	debugmsg("begin read..\n");
	while(cirbuf_empty(&dev->rx_buf))
	{
		debugmsg("go to bed!\n");
		dev->rx_isnempty = 0;
		ret = wait_event_interruptible(spi_waitq, dev->rx_isnempty);
		if(ret != 0)
		{
			have_signal = 1;
			break;
		}
	}
	if(have_signal)
	{
		debugmsg("receive signal...!\n");
		real_read = -1;
	}
	else
	{
		debugmsg("copy data to user space.\n");
		spi_int_rxfifordy_off(spi);
		real_read = copy_cirbuf_to_user(&dev->rx_buf, buf, count);
		debugmsg("copy finish!\n");
		spi_int_rxfifordy_on(spi);
	}
	debugmsg("read_read: %d byte\n", real_read);
	return real_read;	
}

static ssize_t spi_write(struct file *filp, const char __user *buf,
						 size_t count, loff_t *offsetx)
{
	int ret = 0;
	int real_write;
	int have_signal = 0;
	struct spi_device *dev = (struct spi_device *) filp->private_data;
	volatile struct spi_reg *spi = dev->spi0;
	debugmsg("spi write begin: dev:%p spi:%p count:%d\n", dev, spi, count);
	if(count <= 0)
		return 0;
	//打开发送通道
	//return 0;
	spi_int_rxfifordy_off(spi);
	spi_rx_off(spi);
	while(cirbuf_full(&dev->tx_buf))
	{
		dev->tx_isfull = 1;
		ret = wait_event_interruptible(spi_waitq, !dev->tx_isfull);
		if(ret != 0)
		{
			have_signal = 1;
			break;
		}
	}
	
	if(have_signal)
	{
		debugmsg("receive signal...!\n");
		real_write = -1;
	}
	else
	{
		spi_int_txfifordy_off(spi);
		real_write =  copy_cirbuf_from_user(&dev->tx_buf, buf, count);		
	}
	if(!cirbuf_empty(&dev->tx_buf))
	{
		spi_tx_rdy_lvl(spi, dev->tx_rdy_lvl);
		spi_tx_on(spi);	
		spi_int_txfifordy_on(spi);
	}
	debugmsg("real write:%d bytes.\n", real_write);
	return real_write;
}

static int spi_release(struct inode *inode, struct file *filp)
{
	
	debugmsg("begin release...\n");
	return 0;
}
static void set_gpio_for_spi(void)
{
	spi_dev.gpb0->gpbcon &= 0xFFFF0000;
	spi_dev.gpb0->gpbcon |= 0x00002222;
	spi_dev.gpb0->gpbdat &= ~(0xff);
	spi_dev.gpb0->gpbup  &= ~(0xff);

}
static void spi_reg_init(volatile struct spi_reg *spi)
{
	info("init spi reg...\n");
	set_gpio_for_spi();			//set gpio pins to spi mode
	*CLK_GATE_IP3 |= (1 << 12);
	//0.reset all reg
	spi_reset_reg(spi);			//reset all spi regs
	//1.set transfer type CPOL CPHA
	spi_set_master(spi);		//master mode
	spi_set_clkcp(spi, CLKCP0);
//	spi_set_clkcp(spi, CLKCP3);
	spi_high_speed_off(spi);    //don't use high speed

	//2.set feedback clock
	spi_fdclk_sel(spi, FD_270);

	//3.set clokc
	spi_clk_set(spi);			//set clksel and enclk(PCLK, ENABLE)
	spi_clk_divide(spi, 5);     //clk scaler is 0

	//4. set spi mode reg
	spi_mode_clr(spi);
	spi_tx_rdy_lvl(spi, 50);
	
	//5. set spi interrupt
	spi_int_all_off(spi);
	//spi_int_rxfifordy_on(spi);
	//spi_int_txfifordy_on(spi);
	
	//6.set packet cnt reg if neccessary
	
	//7.set tx or rx channel on
	spi_rx_off(spi);				//open rx chanel
	spi_tx_off(spi);				//open tx chanel

	//8. set nssout low to stat tx or rx operaton
	spi_cs_master(spi);

	show_config(spi);
	show_status(spi);
}
static int __init spi_init(void)
{
	int ret;
	info("begin init...\n");
	//注册设备
	ret = misc_register(spi_dev.misc);
	if(ret != 0)
	{
		info("misc register failed\n");
		goto err0;
	}
	//映射spi0的所有寄存器
	spi_dev.spi0 = (struct spi_reg *)ioremap(SPI0_BASE_ADDR, 48);
	if(spi_dev.spi0 == NULL)
	{
		ret = -1;
		info("ioremap spi reg failed\n");
		goto err1;
	}

	//映射管脚功能控制寄存器
	spi_dev.gpb0 = (struct gpb_reg *)ioremap(GPB_BASE_ADDR, 12);
	if(spi_dev.gpb0 == NULL)
	{
		info("ioremap gbp reg failed\n");
		goto err2;
	}

	//映射时钟管理寄存器
	if((CLK_GATE_IP3 = (uint32*)ioremap(s5pv210_CLK, 4)) == NULL)
	{
		info("ioremap CLK_GATE_IP3 failed!\n");
		goto err3;
	}

	//申请spi0的中断
	spi_dev.spi_irq = IRQ_SPI0;
	if((ret = request_irq(spi_dev.spi_irq, spi_interrupt, 
		  					IRQF_DISABLED, DEV_NAME, NULL))!=0)
	{
		info("request irq failed!\n");
		goto err4;
	}

	//申请从设备中断
	//s3c_gpio_cfgpin(RCV_INT_PORT, S3C_GPIO_PULL_NONE);
	spi_dev.rcv_irq = gpio_to_irq(RCV_INT_PORT);
	if((ret = request_irq(spi_dev.rcv_irq, rcv_interrupt, IRQ_TYPE_EDGE_BOTH, 
				"RCV_IRQ", NULL)) != 0)
	{
		info("request rcv irq failed!\n");
		goto err5;
	}

	debugmsg("spi:%p clk:%p gpb:%p spi_irq:%d rcv_irq:%d\n", spi_dev.spi0,CLK_GATE_IP3, spi_dev.gpb0, spi_dev.spi_irq, spi_dev.rcv_irq);
	//初始化spi0的寄存器为主设备
	spi_reg_init(spi_dev.spi0);
	return 0;
err5:
	free_irq(spi_dev.spi_irq, NULL);
err4:	
	iounmap(CLK_GATE_IP3);	
err3:
	iounmap(spi_dev.gpb0);		
err2:
	iounmap(spi_dev.spi0);
err1:
	misc_deregister(spi_dev.misc);
err0:	
	info("spi init failed!\n");
	return -1;
}
static void __exit spi_exit(void)
{
	info("begin exit...\n");
	misc_deregister(spi_dev.misc);
	iounmap(spi_dev.spi0);
	iounmap(spi_dev.gpb0);	
	iounmap(CLK_GATE_IP3);
	free_irq(spi_dev.spi_irq, NULL);
	free_irq(spi_dev.rcv_irq, NULL);
}

module_init(spi_init);
module_exit(spi_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("WYG-HDY-TYY");
MODULE_DESCRIPTION("s5pv210 spi master driver");
