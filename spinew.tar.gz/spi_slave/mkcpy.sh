#!/bin/bash
make && scp spi_slave.ko root@192.168.0.121:/
