#!/bin/bash
make && scp spi_master.ko root@192.168.0.73:/
