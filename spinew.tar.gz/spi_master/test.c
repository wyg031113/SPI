#include<stdio.h>
#define SETDATA(reg,v,s,len) {reg &= (~((1<<(s+len))-1) | ((1<<s)-1));\
							  reg |= (v&((1<<len)-1))<<s;}
int main()
{
	int x = 0x12345678;
	SETDATA(x, 0x9999, 8, 16);
	printf("x=%x\n", x);
	return 0;
}
